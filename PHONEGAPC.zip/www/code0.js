gdjs.IntroCode = {};
gdjs.IntroCode.GDLogointroObjects1= [];
gdjs.IntroCode.GDLogointroObjects2= [];

gdjs.IntroCode.conditionTrue_0 = {val:false};
gdjs.IntroCode.condition0IsTrue_0 = {val:false};
gdjs.IntroCode.condition1IsTrue_0 = {val:false};


gdjs.IntroCode.eventsList0xb2358 = function(runtimeScene) {

{


gdjs.IntroCode.condition0IsTrue_0.val = false;
{
gdjs.IntroCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.IntroCode.condition0IsTrue_0.val) {
}

}


{

gdjs.IntroCode.GDLogointroObjects1.createFrom(runtimeScene.getObjects("Logointro"));

gdjs.IntroCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.IntroCode.GDLogointroObjects1.length;i<l;++i) {
    if ( gdjs.IntroCode.GDLogointroObjects1[i].timerElapsedTime("intro", 3) ) {
        gdjs.IntroCode.condition0IsTrue_0.val = true;
        gdjs.IntroCode.GDLogointroObjects1[k] = gdjs.IntroCode.GDLogointroObjects1[i];
        ++k;
    }
}
gdjs.IntroCode.GDLogointroObjects1.length = k;}if (gdjs.IntroCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


}; //End of gdjs.IntroCode.eventsList0xb2358


gdjs.IntroCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();
gdjs.IntroCode.GDLogointroObjects1.length = 0;
gdjs.IntroCode.GDLogointroObjects2.length = 0;

gdjs.IntroCode.eventsList0xb2358(runtimeScene);
return;
}
gdjs['IntroCode'] = gdjs.IntroCode;
