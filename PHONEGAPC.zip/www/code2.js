gdjs.Level1Code = {};

gdjs.Level1Code.conditionTrue_0 = {val:false};
gdjs.Level1Code.condition0IsTrue_0 = {val:false};


gdjs.Level1Code.eventsList0xb2358 = function(runtimeScene) {

}; //End of gdjs.Level1Code.eventsList0xb2358


gdjs.Level1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level1Code.eventsList0xb2358(runtimeScene);
return;
}
gdjs['Level1Code'] = gdjs.Level1Code;
