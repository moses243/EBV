gdjs.MenuCode = {};
gdjs.MenuCode.GDBgObjects1= [];
gdjs.MenuCode.GDBgObjects2= [];
gdjs.MenuCode.GDBgObjects3= [];
gdjs.MenuCode.GDLogoblaObjects1= [];
gdjs.MenuCode.GDLogoblaObjects2= [];
gdjs.MenuCode.GDLogoblaObjects3= [];
gdjs.MenuCode.GDHelptouchObjects1= [];
gdjs.MenuCode.GDHelptouchObjects2= [];
gdjs.MenuCode.GDHelptouchObjects3= [];
gdjs.MenuCode.GDLeveltouchObjects1= [];
gdjs.MenuCode.GDLeveltouchObjects2= [];
gdjs.MenuCode.GDLeveltouchObjects3= [];
gdjs.MenuCode.GDPlaytouchObjects1= [];
gdjs.MenuCode.GDPlaytouchObjects2= [];
gdjs.MenuCode.GDPlaytouchObjects3= [];
gdjs.MenuCode.GDTitlegameObjects1= [];
gdjs.MenuCode.GDTitlegameObjects2= [];
gdjs.MenuCode.GDTitlegameObjects3= [];
gdjs.MenuCode.GDPlaystoreObjects1= [];
gdjs.MenuCode.GDPlaystoreObjects2= [];
gdjs.MenuCode.GDPlaystoreObjects3= [];
gdjs.MenuCode.GDFacebookObjects1= [];
gdjs.MenuCode.GDFacebookObjects2= [];
gdjs.MenuCode.GDFacebookObjects3= [];
gdjs.MenuCode.GDCloseObjects1= [];
gdjs.MenuCode.GDCloseObjects2= [];
gdjs.MenuCode.GDCloseObjects3= [];
gdjs.MenuCode.GDBgtouchObjects1= [];
gdjs.MenuCode.GDBgtouchObjects2= [];
gdjs.MenuCode.GDBgtouchObjects3= [];
gdjs.MenuCode.GDClosealertObjects1= [];
gdjs.MenuCode.GDClosealertObjects2= [];
gdjs.MenuCode.GDClosealertObjects3= [];
gdjs.MenuCode.GDClosegameObjects1= [];
gdjs.MenuCode.GDClosegameObjects2= [];
gdjs.MenuCode.GDClosegameObjects3= [];

gdjs.MenuCode.conditionTrue_0 = {val:false};
gdjs.MenuCode.condition0IsTrue_0 = {val:false};
gdjs.MenuCode.condition1IsTrue_0 = {val:false};


gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaytouchObjects2Objects = Hashtable.newFrom({"Playtouch": gdjs.MenuCode.GDPlaytouchObjects2});gdjs.MenuCode.eventsList0x6f9268 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Level1", false);
}}

}


}; //End of gdjs.MenuCode.eventsList0x6f9268
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaytouchObjects2Objects = Hashtable.newFrom({"Playtouch": gdjs.MenuCode.GDPlaytouchObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDLeveltouchObjects2Objects = Hashtable.newFrom({"Leveltouch": gdjs.MenuCode.GDLeveltouchObjects2});gdjs.MenuCode.eventsList0x6fbe68 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


}; //End of gdjs.MenuCode.eventsList0x6fbe68
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDLeveltouchObjects2Objects = Hashtable.newFrom({"Leveltouch": gdjs.MenuCode.GDLeveltouchObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDHelptouchObjects2Objects = Hashtable.newFrom({"Helptouch": gdjs.MenuCode.GDHelptouchObjects2});gdjs.MenuCode.eventsList0x6fcf78 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


}; //End of gdjs.MenuCode.eventsList0x6fcf78
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDHelptouchObjects2Objects = Hashtable.newFrom({"Helptouch": gdjs.MenuCode.GDHelptouchObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaystoreObjects2Objects = Hashtable.newFrom({"Playstore": gdjs.MenuCode.GDPlaystoreObjects2});gdjs.MenuCode.eventsList0x662380 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


}; //End of gdjs.MenuCode.eventsList0x662380
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaystoreObjects2Objects = Hashtable.newFrom({"Playstore": gdjs.MenuCode.GDPlaystoreObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDFacebookObjects2Objects = Hashtable.newFrom({"Facebook": gdjs.MenuCode.GDFacebookObjects2});gdjs.MenuCode.eventsList0x689010 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}}

}


}; //End of gdjs.MenuCode.eventsList0x689010
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDFacebookObjects2Objects = Hashtable.newFrom({"Facebook": gdjs.MenuCode.GDFacebookObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDCloseObjects2Objects = Hashtable.newFrom({"Close": gdjs.MenuCode.GDCloseObjects2});gdjs.MenuCode.eventsList0x6ff858 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "alert");
}}

}


}; //End of gdjs.MenuCode.eventsList0x6ff858
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDCloseObjects2Objects = Hashtable.newFrom({"Close": gdjs.MenuCode.GDCloseObjects2});gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDClosegameObjects2Objects = Hashtable.newFrom({"Closegame": gdjs.MenuCode.GDClosegameObjects2});gdjs.MenuCode.eventsList0x6ffe58 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.stopGame(runtimeScene);
}}

}


}; //End of gdjs.MenuCode.eventsList0x6ffe58
gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDClosegameObjects1Objects = Hashtable.newFrom({"Closegame": gdjs.MenuCode.GDClosegameObjects1});gdjs.MenuCode.eventsList0x6f9190 = function(runtimeScene) {

{

gdjs.MenuCode.GDPlaytouchObjects2.createFrom(runtimeScene.getObjects("Playtouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaytouchObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDPlaytouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDPlaytouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDPlaytouchObjects2[i].setAnimationName("Playlight");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x6f9268(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDPlaytouchObjects2.createFrom(runtimeScene.getObjects("Playtouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaytouchObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDPlaytouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDPlaytouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDPlaytouchObjects2[i].setAnimationName("Playpose");
}
}}

}


{

gdjs.MenuCode.GDLeveltouchObjects2.createFrom(runtimeScene.getObjects("Leveltouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDLeveltouchObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDLeveltouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDLeveltouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDLeveltouchObjects2[i].setAnimationName("Levellight");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x6fbe68(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDLeveltouchObjects2.createFrom(runtimeScene.getObjects("Leveltouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDLeveltouchObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDLeveltouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDLeveltouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDLeveltouchObjects2[i].setAnimationName("Levelpose");
}
}}

}


{

gdjs.MenuCode.GDHelptouchObjects2.createFrom(runtimeScene.getObjects("Helptouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDHelptouchObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDHelptouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDHelptouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDHelptouchObjects2[i].setAnimationName("Helplight");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x6fcf78(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDHelptouchObjects2.createFrom(runtimeScene.getObjects("Helptouch"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDHelptouchObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDHelptouchObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDHelptouchObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDHelptouchObjects2[i].setAnimationName("Helppose");
}
}}

}


{

gdjs.MenuCode.GDPlaystoreObjects2.createFrom(runtimeScene.getObjects("Playstore"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaystoreObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDPlaystoreObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDPlaystoreObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDPlaystoreObjects2[i].setAnimationName("Playstoremouse");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x662380(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDPlaystoreObjects2.createFrom(runtimeScene.getObjects("Playstore"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDPlaystoreObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDPlaystoreObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDPlaystoreObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDPlaystoreObjects2[i].setAnimationName("Playstorepose");
}
}}

}


{

gdjs.MenuCode.GDFacebookObjects2.createFrom(runtimeScene.getObjects("Facebook"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDFacebookObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDFacebookObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDFacebookObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDFacebookObjects2[i].setAnimationName("Facebookmouse");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x689010(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDFacebookObjects2.createFrom(runtimeScene.getObjects("Facebook"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDFacebookObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDFacebookObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDFacebookObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDFacebookObjects2[i].setAnimationName("Facebookpose");
}
}}

}


{

gdjs.MenuCode.GDCloseObjects2.createFrom(runtimeScene.getObjects("Close"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDCloseObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDCloseObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDCloseObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDCloseObjects2[i].setAnimationName("Closemouse");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x6ff858(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDCloseObjects2.createFrom(runtimeScene.getObjects("Close"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDCloseObjects2Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDCloseObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDCloseObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDCloseObjects2[i].setAnimationName("Closepose");
}
}}

}


{

gdjs.MenuCode.GDClosegameObjects2.createFrom(runtimeScene.getObjects("Closegame"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDClosegameObjects2Objects, runtimeScene, true, false);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDClosegameObjects2 */
{for(var i = 0, len = gdjs.MenuCode.GDClosegameObjects2.length ;i < len;++i) {
    gdjs.MenuCode.GDClosegameObjects2[i].setAnimationName("CloseGmouse");
}
}
{ //Subevents
gdjs.MenuCode.eventsList0x6ffe58(runtimeScene);} //End of subevents
}

}


{

gdjs.MenuCode.GDClosegameObjects1.createFrom(runtimeScene.getObjects("Closegame"));

gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.MenuCode.mapOfGDgdjs_46MenuCode_46GDClosegameObjects1Objects, runtimeScene, true, true);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
/* Reuse gdjs.MenuCode.GDClosegameObjects1 */
{for(var i = 0, len = gdjs.MenuCode.GDClosegameObjects1.length ;i < len;++i) {
    gdjs.MenuCode.GDClosegameObjects1[i].setAnimationName("CloseGpose");
}
}}

}


}; //End of gdjs.MenuCode.eventsList0x6f9190
gdjs.MenuCode.eventsList0xb2358 = function(runtimeScene) {

{


gdjs.MenuCode.condition0IsTrue_0.val = false;
{
gdjs.MenuCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.MenuCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "alert");
}}

}


{



}


{


gdjs.MenuCode.eventsList0x6f9190(runtimeScene);
}


}; //End of gdjs.MenuCode.eventsList0xb2358


gdjs.MenuCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();
gdjs.MenuCode.GDBgObjects1.length = 0;
gdjs.MenuCode.GDBgObjects2.length = 0;
gdjs.MenuCode.GDBgObjects3.length = 0;
gdjs.MenuCode.GDLogoblaObjects1.length = 0;
gdjs.MenuCode.GDLogoblaObjects2.length = 0;
gdjs.MenuCode.GDLogoblaObjects3.length = 0;
gdjs.MenuCode.GDHelptouchObjects1.length = 0;
gdjs.MenuCode.GDHelptouchObjects2.length = 0;
gdjs.MenuCode.GDHelptouchObjects3.length = 0;
gdjs.MenuCode.GDLeveltouchObjects1.length = 0;
gdjs.MenuCode.GDLeveltouchObjects2.length = 0;
gdjs.MenuCode.GDLeveltouchObjects3.length = 0;
gdjs.MenuCode.GDPlaytouchObjects1.length = 0;
gdjs.MenuCode.GDPlaytouchObjects2.length = 0;
gdjs.MenuCode.GDPlaytouchObjects3.length = 0;
gdjs.MenuCode.GDTitlegameObjects1.length = 0;
gdjs.MenuCode.GDTitlegameObjects2.length = 0;
gdjs.MenuCode.GDTitlegameObjects3.length = 0;
gdjs.MenuCode.GDPlaystoreObjects1.length = 0;
gdjs.MenuCode.GDPlaystoreObjects2.length = 0;
gdjs.MenuCode.GDPlaystoreObjects3.length = 0;
gdjs.MenuCode.GDFacebookObjects1.length = 0;
gdjs.MenuCode.GDFacebookObjects2.length = 0;
gdjs.MenuCode.GDFacebookObjects3.length = 0;
gdjs.MenuCode.GDCloseObjects1.length = 0;
gdjs.MenuCode.GDCloseObjects2.length = 0;
gdjs.MenuCode.GDCloseObjects3.length = 0;
gdjs.MenuCode.GDBgtouchObjects1.length = 0;
gdjs.MenuCode.GDBgtouchObjects2.length = 0;
gdjs.MenuCode.GDBgtouchObjects3.length = 0;
gdjs.MenuCode.GDClosealertObjects1.length = 0;
gdjs.MenuCode.GDClosealertObjects2.length = 0;
gdjs.MenuCode.GDClosealertObjects3.length = 0;
gdjs.MenuCode.GDClosegameObjects1.length = 0;
gdjs.MenuCode.GDClosegameObjects2.length = 0;
gdjs.MenuCode.GDClosegameObjects3.length = 0;

gdjs.MenuCode.eventsList0xb2358(runtimeScene);
return;
}
gdjs['MenuCode'] = gdjs.MenuCode;
