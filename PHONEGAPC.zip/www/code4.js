gdjs.Level2Code = {};

gdjs.Level2Code.conditionTrue_0 = {val:false};
gdjs.Level2Code.condition0IsTrue_0 = {val:false};


gdjs.Level2Code.eventsList0xb2358 = function(runtimeScene) {

}; //End of gdjs.Level2Code.eventsList0xb2358


gdjs.Level2Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Level2Code.eventsList0xb2358(runtimeScene);
return;
}
gdjs['Level2Code'] = gdjs.Level2Code;
