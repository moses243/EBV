gdjs.Menu1Code = {};

gdjs.Menu1Code.conditionTrue_0 = {val:false};
gdjs.Menu1Code.condition0IsTrue_0 = {val:false};


gdjs.Menu1Code.eventsList0xb2358 = function(runtimeScene) {

}; //End of gdjs.Menu1Code.eventsList0xb2358


gdjs.Menu1Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Menu1Code.eventsList0xb2358(runtimeScene);
return;
}
gdjs['Menu1Code'] = gdjs.Menu1Code;
